import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { Colors } from "../constants/Colors";

export default function NotFound() {
  const router = useRouter();
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Screen not found</Text>
      <TouchableOpacity onPress={() => router.replace("/(tabs)")} style={styles.btn}>
        <Text style={styles.btnText}>Go home</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, alignItems: "center", justifyContent: "center", padding: 24 },
  title:     { color: Colors.text, fontSize: 18, fontFamily: "Inter_600SemiBold", marginBottom: 24 },
  btn:       { backgroundColor: Colors.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  btnText:   { color: "#fff", fontFamily: "Inter_600SemiBold" },
});
