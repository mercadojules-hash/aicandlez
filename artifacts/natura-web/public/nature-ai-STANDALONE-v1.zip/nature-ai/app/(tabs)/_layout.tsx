import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";

type FeatherName = keyof typeof Feather.glyphMap;

const TAB_ICON: Record<string, FeatherName> = {
  index:    "home",
  "ask-ai": "message-circle",
  plans:    "list",
  recipes:  "book-open",
  learn:    "graduation-cap",
  profile:  "user",
};

function TabIcon({ name, color, size }: { name: FeatherName; color: string; size: number }) {
  return <Feather name={name} color={color} size={size} />;
}

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.card,
          borderTopColor:  Colors.border,
          borderTopWidth:  1,
          paddingTop:      8,
          paddingBottom:   Platform.OS === "ios" ? 24 : 8,
          height:          Platform.OS === "ios" ? 84 : 64,
        },
        tabBarActiveTintColor:   Colors.primary,
        tabBarInactiveTintColor: Colors.textDim,
        tabBarLabelStyle: {
          fontSize:   10,
          fontFamily: "Inter_500Medium",
          marginTop:  2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: ({ color, size }) => <TabIcon name="home" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="ask-ai"
        options={{
          title: "Ask AI",
          tabBarIcon: ({ color, size }) => <TabIcon name="message-circle" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="plans"
        options={{
          title: "Plans",
          tabBarIcon: ({ color, size }) => <TabIcon name="list" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="recipes"
        options={{
          title: "Recipes",
          tabBarIcon: ({ color, size }) => <TabIcon name="book-open" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="learn"
        options={{
          title: "Learn",
          tabBarIcon: ({ color, size }) => <TabIcon name="graduation-cap" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: "Profile",
          tabBarIcon: ({ color, size }) => <TabIcon name="user" color={color} size={size} />,
        }}
      />
    </Tabs>
  );
}
