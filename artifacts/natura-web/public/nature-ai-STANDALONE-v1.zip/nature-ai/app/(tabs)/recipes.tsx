import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

type Tab  = "Recipes" | "Grocery List";
type Goal = "all" | "immunity" | "energy" | "stress" | "sleep" | "digestion";

interface Recipe {
  id: string; title: string; description: string; goal: Goal;
  prepTime: string; emoji: string; color: string;
  ingredients: string[]; steps: string[];
}

const RECIPES: Recipe[] = [
  {
    id: "r1", emoji: "🍵", color: "#4db87a", goal: "immunity", prepTime: "5 min",
    title: "Immunity Golden Milk",
    description: "A warming blend of turmeric, ginger and black pepper — supports inflammation and immunity.",
    ingredients: ["1 cup oat milk", "½ tsp turmeric", "¼ tsp ginger", "Pinch of black pepper", "1 tsp honey"],
    steps: ["Warm milk on low heat", "Whisk in turmeric, ginger, black pepper", "Pour into mug", "Sweeten with honey"],
  },
  {
    id: "r2", emoji: "🫖", color: "#8B7FD4", goal: "sleep", prepTime: "10 min",
    title: "Sleepy Chamomile Tea Blend",
    description: "Chamomile with lavender and passionflower — a traditional bedtime tonic.",
    ingredients: ["2 tsp dried chamomile", "½ tsp dried lavender", "1 tsp passionflower", "1 cup hot water", "Honey to taste"],
    steps: ["Combine herbs in infuser", "Pour 90°C water over herbs", "Steep 7–10 minutes", "Strain and sweeten"],
  },
  {
    id: "r3", emoji: "🥗", color: "#F5A623", goal: "energy", prepTime: "15 min",
    title: "Energy Green Bowl",
    description: "Nutrient-dense greens with seeds and lemon dressing to fuel sustained energy.",
    ingredients: ["2 cups spinach + kale", "½ avocado", "2 tbsp pumpkin seeds", "¼ cup edamame", "Lemon + olive oil dressing"],
    steps: ["Wash and chop greens", "Add avocado and edamame", "Scatter pumpkin seeds", "Drizzle dressing and toss"],
  },
  {
    id: "r4", emoji: "🍲", color: "#45B7AA", goal: "digestion", prepTime: "20 min",
    title: "Ginger Miso Broth",
    description: "A gut-warming broth with miso, ginger and seaweed — excellent for digestion.",
    ingredients: ["4 cups filtered water", "2 tbsp white miso", "1 inch grated ginger", "1 sheet nori", "Spring onions"],
    steps: ["Bring water to simmer (not boil)", "Dissolve miso in a little warm water", "Add ginger, nori strips", "Stir in miso. Garnish with spring onions."],
  },
  {
    id: "r5", emoji: "🧉", color: "#F5A623", goal: "stress", prepTime: "5 min",
    title: "Ashwagandha Calm Latte",
    description: "Adaptogenic ashwagandha with warm oat milk and cinnamon — supports cortisol balance.",
    ingredients: ["1 cup oat milk", "½ tsp ashwagandha powder", "Pinch of cinnamon", "¼ tsp cardamom", "1 tsp maple syrup"],
    steps: ["Warm oat milk gently", "Whisk in ashwagandha and spices", "Sweeten with maple syrup", "Froth and serve"],
  },
  {
    id: "r6", emoji: "🍓", color: "#4db87a", goal: "immunity", prepTime: "5 min",
    title: "Berry Elderberry Smoothie",
    description: "Antioxidant-rich smoothie with elderberry syrup, mixed berries and kefir.",
    ingredients: ["1 cup frozen mixed berries", "1 tbsp elderberry syrup", "½ cup kefir", "1 banana", "Handful of spinach"],
    steps: ["Add all ingredients to blender", "Blend until smooth", "Add water to adjust thickness", "Serve immediately"],
  },
];

const FILTERS: { label: string; value: Goal }[] = [
  { label: "All",       value: "all"       },
  { label: "Immunity",  value: "immunity"  },
  { label: "Energy",    value: "energy"    },
  { label: "Stress",    value: "stress"    },
  { label: "Sleep",     value: "sleep"     },
  { label: "Digestion", value: "digestion" },
];

interface GroceryItem { id: string; name: string; checked: boolean; }

export default function RecipesScreen() {
  const [tab, setTab]           = useState<Tab>("Recipes");
  const [filter, setFilter]     = useState<Goal>("all");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [grocery, setGrocery]   = useState<GroceryItem[]>([]);

  const filtered = filter === "all" ? RECIPES : RECIPES.filter((r) => r.goal === filter);

  const addToGrocery = (recipe: Recipe) => {
    setGrocery((prev) => {
      const existing = new Set(prev.map((g) => g.name.toLowerCase()));
      const newItems = recipe.ingredients
        .filter((ing) => !existing.has(ing.toLowerCase()))
        .map((name) => ({ id: Date.now() + Math.random() + name, name, checked: false }));
      return [...prev, ...newItems];
    });
    setTab("Grocery List");
  };

  const toggle = (id: string) => setGrocery((p) => p.map((g) => g.id === id ? { ...g, checked: !g.checked } : g));
  const clear  = ()           => setGrocery((p) => p.filter((g) => !g.checked));

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Recipes</Text>
        <View style={styles.tabs}>
          {(["Recipes", "Grocery List"] as Tab[]).map((t) => (
            <TouchableOpacity key={t} style={[styles.tabBtn, tab === t && styles.tabBtnActive]} onPress={() => setTab(t)}>
              <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>
                {t}{t === "Grocery List" && grocery.length > 0 ? ` (${grocery.filter((g) => !g.checked).length})` : ""}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {tab === "Recipes" && (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterBar} contentContainerStyle={{ paddingHorizontal: spacing.md, paddingBottom: 8 }}>
            {FILTERS.map(({ label, value }) => (
              <TouchableOpacity key={value} style={[styles.chip, filter === value && styles.chipActive]} onPress={() => setFilter(value)}>
                <Text style={[styles.chipText, filter === value && styles.chipTextActive]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
            {filtered.map((recipe) => {
              const open = expanded === recipe.id;
              return (
                <View key={recipe.id} style={styles.card}>
                  <View style={[styles.cardHero, { backgroundColor: recipe.color + "20" }]}>
                    <Text style={styles.emoji}>{recipe.emoji}</Text>
                    <TouchableOpacity style={styles.addBtn} onPress={() => addToGrocery(recipe)}>
                      <Feather name="shopping-cart" size={14} color={Colors.text} />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.cardBody}>
                    <View style={styles.cardMeta}>
                      <View style={[styles.goalPill, { backgroundColor: recipe.color + "22" }]}>
                        <Text style={[styles.goalText, { color: recipe.color }]}>{recipe.goal}</Text>
                      </View>
                      <Text style={styles.prepTime}>⏱ {recipe.prepTime}</Text>
                    </View>
                    <Text style={styles.cardTitle}>{recipe.title}</Text>
                    <Text style={styles.cardDesc}>{recipe.description}</Text>
                    {open && (
                      <>
                        <Text style={styles.subheading}>Ingredients</Text>
                        {recipe.ingredients.map((ing, i) => (
                          <Text key={i} style={styles.ingredient}>• {ing}</Text>
                        ))}
                        <Text style={styles.subheading}>Instructions</Text>
                        {recipe.steps.map((s, i) => (
                          <View key={i} style={styles.stepRow}>
                            <Text style={[styles.stepNum, { color: recipe.color }]}>{i + 1}.</Text>
                            <Text style={styles.stepText}>{s}</Text>
                          </View>
                        ))}
                      </>
                    )}
                    <TouchableOpacity style={styles.expandBtn} onPress={() => setExpanded(open ? null : recipe.id)}>
                      <Feather name={open ? "chevron-up" : "chevron-down"} size={14} color={Colors.textDim} />
                      <Text style={styles.expandText}>{open ? "Less" : "View recipe"}</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })}
            <View style={{ height: 32 }} />
          </ScrollView>
        </>
      )}

      {tab === "Grocery List" && (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {grocery.length === 0 ? (
            <View style={styles.empty}>
              <Feather name="shopping-cart" size={40} color={Colors.border} />
              <Text style={styles.emptyTitle}>No items yet</Text>
              <Text style={styles.emptySub}>Tap the cart icon on any recipe to add ingredients here.</Text>
            </View>
          ) : (
            <>
              {grocery.map((item) => (
                <TouchableOpacity key={item.id} style={styles.groceryItem} onPress={() => toggle(item.id)}>
                  <View style={[styles.checkbox, item.checked && { backgroundColor: Colors.primary, borderColor: Colors.primary }]}>
                    {item.checked && <Feather name="check" size={11} color="#0a1f14" />}
                  </View>
                  <Text style={[styles.groceryName, item.checked && styles.groceryChecked]}>{item.name}</Text>
                </TouchableOpacity>
              ))}
              {grocery.some((g) => g.checked) && (
                <TouchableOpacity style={styles.clearBtn} onPress={clear}>
                  <Feather name="trash-2" size={14} color={Colors.error} />
                  <Text style={styles.clearText}>Clear checked</Text>
                </TouchableOpacity>
              )}
            </>
          )}
          <View style={{ height: 32 }} />
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:          { flex: 1, backgroundColor: Colors.background },
  header:        { paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.sm },
  pageTitle:     { color: Colors.text, fontSize: fontSize.xxl, fontFamily: "Inter_700Bold", marginBottom: spacing.sm },
  tabs:          { flexDirection: "row", backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" },
  tabBtn:        { flex: 1, alignItems: "center", paddingVertical: spacing.sm },
  tabBtnActive:  { backgroundColor: Colors.primary + "22" },
  tabText:       { color: Colors.textMuted, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  tabTextActive: { color: Colors.primary },
  filterBar:     { flexGrow: 0 },
  chip:          { paddingHorizontal: 14, paddingVertical: 6, borderRadius: radius.full, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card, marginRight: 8 },
  chipActive:    { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText:      { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_500Medium" },
  chipTextActive:{ color: "#0a1f14" },
  scroll:        { padding: spacing.md, paddingTop: 0 },
  card:          { backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, overflow: "hidden", marginBottom: spacing.md },
  cardHero:      { height: 100, alignItems: "center", justifyContent: "center", position: "relative" },
  emoji:         { fontSize: 40 },
  addBtn:        { position: "absolute", top: spacing.sm, right: spacing.sm, width: 32, height: 32, borderRadius: 16, backgroundColor: "rgba(0,0,0,0.45)", alignItems: "center", justifyContent: "center" },
  cardBody:      { padding: spacing.md },
  cardMeta:      { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: spacing.sm },
  goalPill:      { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  goalText:      { fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", textTransform: "capitalize" },
  prepTime:      { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  cardTitle:     { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
  cardDesc:      { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", lineHeight: 18, marginBottom: spacing.sm },
  subheading:    { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 1, marginTop: spacing.sm, marginBottom: 4 },
  ingredient:    { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", marginBottom: 2 },
  stepRow:       { flexDirection: "row", gap: 6, marginBottom: 4 },
  stepNum:       { fontSize: fontSize.sm, fontFamily: "Inter_700Bold", width: 16 },
  stepText:      { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 18 },
  expandBtn:     { flexDirection: "row", alignItems: "center", gap: 4, marginTop: spacing.sm },
  expandText:    { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  empty:         { alignItems: "center", paddingVertical: 60 },
  emptyTitle:    { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginTop: spacing.md, marginBottom: 4 },
  emptySub:      { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", textAlign: "center" },
  groceryItem:   { flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.sm },
  checkbox:      { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: Colors.border, alignItems: "center", justifyContent: "center" },
  groceryName:   { flex: 1, color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  groceryChecked:{ color: Colors.textMuted, textDecorationLine: "line-through" },
  clearBtn:      { flexDirection: "row", alignItems: "center", gap: spacing.sm, justifyContent: "center", padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, marginTop: spacing.sm },
  clearText:     { color: Colors.error, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
});
