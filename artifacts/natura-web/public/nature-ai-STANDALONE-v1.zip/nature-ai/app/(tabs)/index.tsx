import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

const TASKS = [
  { id: "1", time: "7:00 AM",  label: "Warm lemon water",     icon: "droplet"  as const, cat: "morning"   },
  { id: "2", time: "7:20 AM",  label: "5-min breathwork",     icon: "wind"     as const, cat: "morning"   },
  { id: "3", time: "8:00 AM",  label: "Nourishing breakfast", icon: "coffee"   as const, cat: "morning"   },
  { id: "4", time: "3:00 PM",  label: "Herbal tea break",     icon: "feather"  as const, cat: "afternoon" },
  { id: "5", time: "6:00 PM",  label: "Evening walk",         icon: "map-pin"  as const, cat: "afternoon" },
  { id: "6", time: "9:00 PM",  label: "Wind-down ritual",     icon: "moon"     as const, cat: "evening"   },
];

const STATS = [
  { icon: "zap"          as const, value: "5",  label: "streak"   },
  { icon: "sun"          as const, value: "72", label: "min today" },
  { icon: "check-circle" as const, value: "3",  label: "done"     },
  { icon: "star"         as const, value: "84", label: "score"    },
];

const hour = new Date().getHours();
const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

export default function HomeScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.brand}>NATURE AI</Text>
            <Text style={styles.brandSub}>AI Wellness Coach</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarLetter}>J</Text>
          </View>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.heroBadge}>
            <Feather name="zap" size={11} color={Colors.primary} />
            <Text style={styles.heroBadgeText}>Energy: Good</Text>
          </View>
          <Text style={styles.heroGreeting}>{greeting}</Text>
          <Text style={styles.heroTitle}>Your Plan for Today</Text>
          <Text style={styles.heroSub}>Personalised steps for your mind, body and energy</Text>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {STATS.map(({ icon, value, label }) => (
            <View key={label} style={styles.statItem}>
              <Feather name={icon} size={16} color={Colors.primary} />
              <Text style={styles.statValue}>{value}</Text>
              <Text style={styles.statLabel}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Today's tasks */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Schedule</Text>
          {TASKS.map((task) => (
            <View key={task.id} style={styles.taskRow}>
              <Text style={styles.taskTime}>{task.time}</Text>
              <View style={styles.taskCard}>
                <View style={styles.taskIcon}>
                  <Feather name={task.icon} size={15} color={Colors.primary} />
                </View>
                <View style={styles.taskInfo}>
                  <Text style={styles.taskLabel}>{task.label}</Text>
                  <Text style={styles.taskCat}>{task.cat}</Text>
                </View>
                <Feather name="chevron-right" size={14} color={Colors.textDim} />
              </View>
            </View>
          ))}
        </View>

        {/* Tip card */}
        <View style={styles.tipCard}>
          <Feather name="sun" size={18} color={Colors.primary} />
          <View style={{ flex: 1 }}>
            <Text style={styles.tipTitle}>Daily Tip</Text>
            <Text style={styles.tipBody}>Morning sunlight within 30 minutes of waking anchors your circadian rhythm and boosts daytime energy.</Text>
          </View>
        </View>

        {/* CTA */}
        <TouchableOpacity style={styles.cta} onPress={() => router.push("/(tabs)/ask-ai")} activeOpacity={0.85}>
          <Feather name="message-circle" size={16} color={Colors.primary} />
          <Text style={styles.ctaText}>Ask the AI anything</Text>
          <Feather name="arrow-right" size={16} color={Colors.primary} />
        </TouchableOpacity>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:          { flex: 1, backgroundColor: Colors.background },
  scroll:        { padding: spacing.md },
  header:        { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.md },
  brand:         { color: Colors.primary, fontSize: fontSize.xs, fontFamily: "Inter_700Bold", letterSpacing: 2 },
  brandSub:      { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  avatar:        { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border, alignItems: "center", justifyContent: "center" },
  avatarLetter:  { color: Colors.primary, fontSize: fontSize.md, fontFamily: "Inter_700Bold" },
  hero:          { backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.md },
  heroBadge:     { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: Colors.primary + "22", alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, marginBottom: spacing.sm },
  heroBadgeText: { color: Colors.primary, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold" },
  heroGreeting:  { color: Colors.textMuted, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", marginBottom: 2 },
  heroTitle:     { color: Colors.text, fontSize: fontSize.xl, fontFamily: "Inter_700Bold", marginBottom: 4 },
  heroSub:       { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  statsRow:      { flexDirection: "row", backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, justifyContent: "space-around", marginBottom: spacing.md },
  statItem:      { alignItems: "center", gap: 3 },
  statValue:     { color: Colors.text, fontSize: fontSize.lg, fontFamily: "Inter_700Bold" },
  statLabel:     { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  section:       { marginBottom: spacing.md },
  sectionTitle:  { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginBottom: spacing.sm },
  taskRow:       { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginBottom: spacing.sm },
  taskTime:      { width: 58, color: Colors.textMuted, fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "right" },
  taskCard:      { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, padding: spacing.sm },
  taskIcon:      { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.primary + "20", alignItems: "center", justifyContent: "center" },
  taskInfo:      { flex: 1 },
  taskLabel:     { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  taskCat:       { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", textTransform: "capitalize" },
  tipCard:       { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, backgroundColor: Colors.primary + "12", borderRadius: radius.md, borderWidth: 1, borderColor: Colors.primary + "33", padding: spacing.md, marginBottom: spacing.md },
  tipTitle:      { color: Colors.primary, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  tipBody:       { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", lineHeight: 16 },
  cta:           { flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.primary + "44", padding: spacing.md },
  ctaText:       { flex: 1, color: Colors.primary, fontSize: fontSize.sm, fontFamily: "Inter_600SemiBold" },
});
