import { useState, useRef, useEffect } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

interface Message { id: string; role: "user" | "ai"; text: string; }

const SUGGESTIONS = [
  { text: "How can I sleep better naturally?",       icon: "moon"    as const },
  { text: "Natural ways to reduce stress",            icon: "feather" as const },
  { text: "How to boost energy without caffeine",     icon: "zap"     as const },
  { text: "Herbs that support the immune system",     icon: "shield"  as const },
  { text: "Foods that help with digestion",           icon: "droplet" as const },
];

const AI_RESPONSES: Record<string, string> = {
  sleep:     "For better sleep, try keeping a consistent bedtime, avoiding caffeine after 2 PM, and dimming lights 1–2 hours before bed. Herbal options like valerian root, passionflower, and chamomile tea have traditional use for supporting relaxation. A cool bedroom (around 18°C) also significantly improves sleep quality.\n\n⚠️ Note: these are educational suggestions, not medical advice.",
  stress:    "To reduce stress naturally, diaphragmatic breathing (inhale 4 counts, exhale 8 counts) activates your parasympathetic nervous system. Adaptogens like ashwagandha and rhodiola have research supporting their role in cortisol regulation. Regular time in green spaces also measurably reduces cortisol.\n\n⚠️ Consult your healthcare provider before adding supplements.",
  energy:    "For natural energy, try delaying caffeine 90 minutes after waking, getting morning sunlight within 30 minutes of rising, and eating a protein-rich breakfast. B vitamins and magnesium support energy metabolism. Even a 10-minute walk increases BDNF — a brain chemical linked to alertness.\n\n⚠️ If fatigue is persistent, speak to a doctor.",
  immune:    "Key immunity supporters include vitamin C (bell peppers, kiwi), zinc (pumpkin seeds, legumes), and vitamin D (sunlight + supplementation). Elderberry and echinacea have traditional use during cold season. A diverse diet with 30+ plant foods weekly supports your gut microbiome, which is central to immunity.\n\n⚠️ Supplements are not replacements for medical care.",
  digestion: "Ginger is one of the most studied digestive aids — it accelerates gastric emptying and reduces nausea. Fennel tea soothes bloating. Probiotic-rich foods (kefir, kimchi, yoghurt) support microbiome diversity. Eating slowly and mindfully significantly reduces digestive discomfort for most people.\n\n⚠️ Persistent digestive symptoms should be evaluated by a doctor.",
  default:   "That's a great wellness question. Generally speaking, most wellness improvements come from four areas: sleep quality, stress regulation, nutrition, and movement. I can go deeper on any of these — just let me know what matters most to you.\n\n⚠️ This is educational information only, not medical advice.",
};

function getAIResponse(text: string): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const lower = text.toLowerCase();
      if (lower.includes("sleep"))             resolve(AI_RESPONSES.sleep);
      else if (lower.includes("stress") || lower.includes("calm") || lower.includes("anxiet")) resolve(AI_RESPONSES.stress);
      else if (lower.includes("energy") || lower.includes("tired") || lower.includes("fatigue")) resolve(AI_RESPONSES.energy);
      else if (lower.includes("immune") || lower.includes("immunity") || lower.includes("herb")) resolve(AI_RESPONSES.immune);
      else if (lower.includes("digest") || lower.includes("gut") || lower.includes("bloat"))     resolve(AI_RESPONSES.digestion);
      else resolve(AI_RESPONSES.default);
    }, 900);
  });
}

export default function AskAIScreen() {
  const [messages, setMessages]   = useState<Message[]>([]);
  const [input, setInput]         = useState("");
  const [loading, setLoading]     = useState(false);
  const scrollRef                 = useRef<ScrollView>(null);

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  }, [messages, loading]);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { id: Date.now() + "u", role: "user", text: text.trim() };
    setMessages((p) => [...p, userMsg]);
    setInput("");
    setLoading(true);
    const reply = await getAIResponse(text.trim());
    setMessages((p) => [...p, { id: Date.now() + "a", role: "ai", text: reply }]);
    setLoading(false);
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={90}>

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerAvatar}>
            <Feather name="activity" size={18} color={Colors.primary} />
          </View>
          <View>
            <Text style={styles.headerSub}>AI Wellness Coach</Text>
            <Text style={styles.headerTitle}>Nature AI</Text>
          </View>
        </View>

        {/* Messages */}
        <ScrollView ref={scrollRef} style={styles.messages} contentContainerStyle={{ padding: spacing.md }} showsVerticalScrollIndicator={false}>
          {messages.length === 0 && (
            <View style={styles.empty}>
              <View style={styles.emptyIcon}>
                <Feather name="activity" size={28} color={Colors.primary} />
              </View>
              <Text style={styles.emptyTitle}>What would you like support with?</Text>
              <Text style={styles.emptySub}>Choose a topic or ask your own question.</Text>
              {SUGGESTIONS.map(({ text, icon }) => (
                <TouchableOpacity key={text} style={styles.suggestion} onPress={() => send(text)} activeOpacity={0.75}>
                  <Feather name={icon} size={16} color={Colors.primary} />
                  <Text style={styles.suggestionText}>{text}</Text>
                  <Feather name="chevron-right" size={14} color={Colors.textDim} />
                </TouchableOpacity>
              ))}
            </View>
          )}

          {messages.map((msg) => (
            <View key={msg.id} style={msg.role === "user" ? styles.userWrap : undefined}>
              {msg.role === "user" ? (
                <View style={styles.userBubble}>
                  <Text style={styles.userText}>{msg.text}</Text>
                </View>
              ) : (
                <View style={styles.aiBubble}>
                  <View style={styles.aiHeader}>
                    <View style={styles.aiDot}><Feather name="activity" size={11} color={Colors.primary} /></View>
                    <Text style={styles.aiLabel}>Nature AI</Text>
                  </View>
                  <Text style={styles.aiText}>{msg.text}</Text>
                </View>
              )}
            </View>
          ))}

          {loading && (
            <View style={styles.aiBubble}>
              <ActivityIndicator size="small" color={Colors.primary} />
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputBar}>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="Ask about sleep, stress, herbs..."
            placeholderTextColor={Colors.textMuted}
            multiline
            onSubmitEditing={() => send(input)}
            returnKeyType="send"
          />
          <TouchableOpacity
            style={[styles.sendBtn, { backgroundColor: input.trim() && !loading ? Colors.primary : Colors.border }]}
            onPress={() => send(input)}
            disabled={!input.trim() || loading}
          >
            <Feather name="arrow-up" size={16} color={input.trim() && !loading ? "#0a1f14" : Colors.textMuted} />
          </TouchableOpacity>
        </View>
        <Text style={styles.disclaimer}>Educational suggestions only — not medical advice</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:           { flex: 1, backgroundColor: Colors.background },
  header:         { flexDirection: "row", alignItems: "center", gap: spacing.sm, padding: spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border },
  headerAvatar:   { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.primary + "22", alignItems: "center", justifyContent: "center" },
  headerSub:      { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  headerTitle:    { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_700Bold" },
  messages:       { flex: 1 },
  empty:          { alignItems: "center", paddingBottom: spacing.md },
  emptyIcon:      { width: 70, height: 70, borderRadius: 35, backgroundColor: Colors.primary + "20", alignItems: "center", justifyContent: "center", marginBottom: spacing.md },
  emptyTitle:     { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginBottom: 6, textAlign: "center" },
  emptySub:       { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", marginBottom: spacing.lg, textAlign: "center" },
  suggestion:     { width: "100%", flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.sm },
  suggestionText: { flex: 1, color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  userWrap:       { alignItems: "flex-end", marginBottom: spacing.sm },
  userBubble:     { maxWidth: "82%", backgroundColor: Colors.primary, borderRadius: radius.lg, padding: spacing.md },
  userText:       { color: "#0a1f14", fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  aiBubble:       { backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.sm },
  aiHeader:       { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: spacing.sm },
  aiDot:          { width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.primary + "22", alignItems: "center", justifyContent: "center" },
  aiLabel:        { color: Colors.primary, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold" },
  aiText:         { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", lineHeight: 20 },
  inputBar:       { flexDirection: "row", alignItems: "flex-end", gap: spacing.sm, padding: spacing.md, borderTopWidth: 1, borderTopColor: Colors.border, backgroundColor: Colors.card },
  input:          { flex: 1, backgroundColor: Colors.background, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, color: Colors.text, padding: spacing.sm, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", maxHeight: 100 },
  sendBtn:        { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  disclaimer:     { color: Colors.textDim, fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "center", paddingVertical: 8, backgroundColor: Colors.card },
});
