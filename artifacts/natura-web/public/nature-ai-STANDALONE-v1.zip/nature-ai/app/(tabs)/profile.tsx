import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Switch } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

const SCALE_LABELS = ["Very low", "Low", "Moderate", "Good", "Excellent"];

const GOALS = ["Better sleep", "Less stress", "More energy", "Stronger immunity", "Better digestion", "Lose weight"];

function ScaleBar({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <View style={bar.wrap}>
      <View style={bar.labelRow}>
        <Text style={bar.label}>{label}</Text>
        <Text style={bar.val}>{SCALE_LABELS[value - 1]}</Text>
      </View>
      <View style={bar.dots}>
        {[1, 2, 3, 4, 5].map((v) => (
          <TouchableOpacity key={v} style={[bar.dot, value >= v && bar.dotFilled, { flex: 1 }]} onPress={() => onChange(v)} />
        ))}
      </View>
    </View>
  );
}

const bar = StyleSheet.create({
  wrap:     { marginBottom: spacing.md },
  labelRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 6 },
  label:    { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  val:      { color: Colors.primary, fontSize: fontSize.sm, fontFamily: "Inter_600SemiBold" },
  dots:     { flexDirection: "row", gap: 6 },
  dot:      { height: 10, borderRadius: 5, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: "transparent" },
  dotFilled:{ backgroundColor: Colors.primary, borderColor: Colors.primary },
});

const STATS = [
  { icon: "zap"          as const, value: "5",  label: "Day Streak", color: "#F5C842" },
  { icon: "check-circle" as const, value: "12", label: "Sessions",   color: Colors.primary },
  { icon: "star"         as const, value: "84", label: "Score",      color: "#A78BFA" },
];

const SETTINGS = [
  { icon: "bell"    as const, label: "Notifications",  sub: "Daily reminders & tips"  },
  { icon: "lock"    as const, label: "Privacy",         sub: "Data & permissions"      },
  { icon: "help-circle" as const, label: "About",        sub: "Nature AI v1.0.0"       },
];

export default function ProfileScreen() {
  const [name, setNameState]       = useState("Jules");
  const [energy, setEnergy]        = useState(3);
  const [stress, setStress]        = useState(3);
  const [sleep, setSleep]          = useState(3);
  const [checkInDone, setDone]     = useState(false);
  const [darkMode, setDarkMode]    = useState(true);
  const [notifs, setNotifs]        = useState(true);
  const [selectedGoals, setGoals]  = useState<string[]>(["Better sleep", "Less stress"]);

  const initial = name ? name[0].toUpperCase() : "J";

  const toggleGoal = (g: string) =>
    setGoals((prev) => prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]);

  const handleCheckIn = () => {
    setDone(true);
    Alert.alert("Check-in saved", "Great job keeping track of your wellbeing today!");
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>

        {/* Avatar */}
        <View style={styles.hero}>
          <View style={styles.avatarRing}>
            <View style={styles.avatar}>
              <Text style={styles.avatarInitial}>{initial}</Text>
            </View>
          </View>
          <Text style={styles.heroName}>{name}</Text>
          <Text style={styles.heroSub}>Your wellness journey</Text>
          <View style={styles.goalsRow}>
            {selectedGoals.slice(0, 2).map((g) => (
              <View key={g} style={styles.goalPill}>
                <Text style={styles.goalText}>{g}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {STATS.map(({ icon, value, label, color }) => (
            <View key={label} style={styles.statItem}>
              <View style={[styles.statIcon, { backgroundColor: color + "22" }]}>
                <Feather name={icon} size={15} color={color} />
              </View>
              <Text style={styles.statValue}>{value}</Text>
              <Text style={styles.statLabel}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Goals */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Goals</Text>
          <View style={styles.goalsGrid}>
            {GOALS.map((g) => {
              const active = selectedGoals.includes(g);
              return (
                <TouchableOpacity key={g} style={[styles.goalChip, active && styles.goalChipActive]} onPress={() => toggleGoal(g)}>
                  {active && <Feather name="check" size={12} color={Colors.primary} />}
                  <Text style={[styles.goalChipText, active && styles.goalChipTextActive]}>{g}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Daily Check-In */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Daily Check-In</Text>
          <Text style={styles.sectionSub}>How are you feeling today?</Text>
          {checkInDone ? (
            <View style={styles.doneRow}>
              <Feather name="check-circle" size={18} color={Colors.primary} />
              <Text style={styles.doneText}>Check-in complete for today</Text>
            </View>
          ) : (
            <>
              <ScaleBar label="Energy"       value={energy} onChange={setEnergy} />
              <ScaleBar label="Stress"       value={stress} onChange={setStress} />
              <ScaleBar label="Sleep quality" value={sleep}  onChange={setSleep} />
              <TouchableOpacity style={styles.submitBtn} onPress={handleCheckIn}>
                <Text style={styles.submitText}>Submit Check-In</Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Preferences */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>
          <View style={styles.prefRow}>
            <Feather name="moon" size={16} color={Colors.textDim} />
            <Text style={styles.prefLabel}>Dark mode</Text>
            <Switch value={darkMode} onValueChange={setDarkMode} trackColor={{ false: Colors.border, true: Colors.primary }} thumbColor="#fff" />
          </View>
          <View style={styles.prefRow}>
            <Feather name="bell" size={16} color={Colors.textDim} />
            <Text style={styles.prefLabel}>Daily reminders</Text>
            <Switch value={notifs} onValueChange={setNotifs} trackColor={{ false: Colors.border, true: Colors.primary }} thumbColor="#fff" />
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          {SETTINGS.map(({ icon, label, sub }) => (
            <TouchableOpacity key={label} style={styles.settingRow} activeOpacity={0.7}>
              <View style={styles.settingIcon}>
                <Feather name={icon} size={16} color={Colors.textDim} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>{label}</Text>
                <Text style={styles.settingSub}>{sub}</Text>
              </View>
              <Feather name="chevron-right" size={16} color={Colors.textDim} />
            </TouchableOpacity>
          ))}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:             { flex: 1, backgroundColor: Colors.background },
  hero:             { alignItems: "center", paddingVertical: spacing.xl },
  avatarRing:       { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: Colors.primary + "55", padding: 4, marginBottom: spacing.sm },
  avatar:           { flex: 1, borderRadius: 40, backgroundColor: Colors.primary + "22", alignItems: "center", justifyContent: "center" },
  avatarInitial:    { color: Colors.primary, fontSize: 32, fontFamily: "Inter_700Bold" },
  heroName:         { color: Colors.text, fontSize: fontSize.xl, fontFamily: "Inter_700Bold", marginBottom: 4 },
  heroSub:          { color: Colors.textMuted, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", marginBottom: spacing.sm },
  goalsRow:         { flexDirection: "row", gap: 6 },
  goalPill:         { backgroundColor: Colors.primary + "22", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  goalText:         { color: Colors.primary, fontSize: fontSize.xs, fontFamily: "Inter_500Medium" },
  statsRow:         { flexDirection: "row", marginHorizontal: spacing.md, backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.md },
  statItem:         { flex: 1, alignItems: "center", gap: 4 },
  statIcon:         { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  statValue:        { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_700Bold" },
  statLabel:        { color: Colors.textMuted, fontSize: 10, fontFamily: "Inter_400Regular" },
  section:          { marginHorizontal: spacing.md, backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.md },
  sectionTitle:     { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  sectionSub:       { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", marginBottom: spacing.md },
  goalsGrid:        { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: spacing.sm },
  goalChip:         { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.full, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.background },
  goalChipActive:   { borderColor: Colors.primary + "77", backgroundColor: Colors.primary + "18" },
  goalChipText:     { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  goalChipTextActive:{ color: Colors.primary },
  doneRow:          { flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: Colors.primary + "15", padding: spacing.md, borderRadius: radius.md },
  doneText:         { color: Colors.primary, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  submitBtn:        { backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.primary + "66", borderRadius: radius.md, padding: spacing.md, alignItems: "center", marginTop: spacing.sm },
  submitText:       { color: Colors.primary, fontSize: fontSize.sm, fontFamily: "Inter_600SemiBold" },
  prefRow:          { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  prefLabel:        { flex: 1, color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  settingRow:       { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  settingIcon:      { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.border + "80", alignItems: "center", justifyContent: "center" },
  settingLabel:     { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  settingSub:       { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
});
