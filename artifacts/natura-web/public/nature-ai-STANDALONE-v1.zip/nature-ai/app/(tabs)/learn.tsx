import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

interface Article {
  id: string; title: string; category: string; readTime: string;
  summary: string; icon: keyof typeof Feather.glyphMap; color: string;
  body: string[]; takeaways: string[];
}

const ARTICLES: Article[] = [
  {
    id: "sleep",        category: "Sleep",       readTime: "4 min", color: "#8B7FD4", icon: "moon",
    title: "Why Your Sleep Is Broken — and How to Fix It",
    summary: "Consistent wake times, cool bedrooms and no blue light are the highest-impact sleep changes you can make.",
    body: [
      "Sleep hygiene refers to the behaviours and environment that promote consistent, high-quality sleep.",
      "Your circadian rhythm is an internal ~24-hour clock. Disrupting it through irregular sleep times or blue light before bed causes measurable impairment.",
      "Core science-backed changes: a consistent wake time, bedroom temperature of 18°C (65°F), and avoiding caffeine after 2 PM.",
    ],
    takeaways: ["Consistent wake times matter more than bedtimes", "Blue light delays melatonin by up to 3 hours", "A cool room (18°C) is one of the best sleep hacks"],
  },
  {
    id: "stress",       category: "Stress",      readTime: "3 min", color: "#F5A623", icon: "zap",
    title: "The Science of Natural Stress Relief",
    summary: "Your breath is the only autonomic function you can consciously control — making it a direct door to calm.",
    body: [
      "Breathing patterns directly affect your autonomic nervous system. Extended exhales activate the parasympathetic 'rest and digest' state.",
      "The 4-7-8 technique (inhale 4, hold 7, exhale 8) and box breathing are both evidence-supported tools for acute stress.",
      "Adaptogens like ashwagandha and rhodiola have research supporting their role in HPA axis regulation and cortisol management.",
    ],
    takeaways: ["Exhale 2× longer than inhale to activate the vagal brake", "Ashwagandha shows measurable cortisol reduction", "5 minutes of breathwork creates real HRV improvement"],
  },
  {
    id: "energy",       category: "Energy",      readTime: "3 min", color: "#4db87a", icon: "sun",
    title: "Morning Habits for All-Day Energy",
    summary: "The first 60 minutes of your day disproportionately affect your energy for the next 16 hours.",
    body: [
      "Morning sunlight within 30 minutes of waking triggers a cortisol peak at its natural time, supporting alertness and a stable mood.",
      "Delaying caffeine 90–120 minutes after waking allows adenosine to clear naturally, making caffeine more effective and longer-lasting.",
      "10 minutes of movement in the morning increases BDNF (brain-derived neurotrophic factor) by up to 200%.",
    ],
    takeaways: ["Sunlight within 30 min anchors your circadian rhythm", "Delay caffeine 90 min after waking for better effect", "Morning movement raises BDNF up to 200%"],
  },
  {
    id: "immunity",     category: "Immunity",    readTime: "3 min", color: "#45B7AA", icon: "shield",
    title: "Foods and Habits That Support Immunity",
    summary: "Diversity of plant foods, vitamin D and sleep quality are the three highest-leverage immunity factors.",
    body: [
      "Your gut microbiome influences roughly 70% of your immune function. Eating 30+ different plant foods weekly measurably improves microbiome diversity.",
      "Vitamin D receptors are found on virtually every immune cell. Deficiency is linked to impaired innate and adaptive immunity.",
      "Turmeric's curcumin has anti-inflammatory properties — and its bioavailability increases 2000% when paired with black pepper (piperine).",
    ],
    takeaways: ["30+ plant foods/week for microbiome diversity", "Vitamin D deficiency impairs immune function", "Black pepper increases turmeric absorption 2000%"],
  },
  {
    id: "gut",          category: "Digestion",   readTime: "4 min", color: "#E87D6B", icon: "heart",
    title: "Your Gut Is Your Second Brain",
    summary: "The gut-brain axis connects your digestive system to your mental health via the vagus nerve.",
    body: [
      "The enteric nervous system contains 100+ million nerve cells and communicates bidirectionally with the brain via the vagus nerve.",
      "Approximately 90% of your body's serotonin is produced in the gut — explaining why gut health affects mood.",
      "Fermented foods (kefir, kimchi, yoghurt) improve microbiome diversity more effectively than probiotic supplements alone.",
    ],
    takeaways: ["90% of serotonin is made in your gut", "Chronic stress directly damages gut lining", "Fermented foods beat supplements for diversity"],
  },
  {
    id: "adaptogens",   category: "Herbs",       readTime: "3 min", color: "#4db87a", icon: "feather",
    title: "What Are Adaptogens — and Do They Work?",
    summary: "Adaptogens are herbs that help your body handle stress and build long-term resilience. Here's the science.",
    body: [
      "Adaptogens are defined by their ability to help the body 'adapt' to physical, chemical and biological stressors in a non-specific way.",
      "Unlike stimulants, adaptogens work to normalise physiological functions — neither over-stimulating nor sedating.",
      "Leading research candidates include ashwagandha (cortisol), rhodiola (fatigue and cognition), and lion's mane (nerve growth factor).",
    ],
    takeaways: ["Adaptogens need 4–8 weeks of consistent use", "Each adaptogen has a unique action profile", "Consult a provider before starting any new supplement"],
  },
];

const QUICK_TIPS = [
  { emoji: "🍋", text: "Warm lemon water before coffee" },
  { emoji: "☀️", text: "Sunlight within 30 min of waking" },
  { emoji: "🌬️", text: "3 deep belly breaths" },
  { emoji: "💧", text: "Hydrate before stimulants" },
  { emoji: "🚶", text: "Walk 10 minutes after lunch" },
];

const CATEGORIES = ["All", "Sleep", "Stress", "Energy", "Immunity", "Digestion", "Herbs"];

function Detail({ article, onClose }: { article: Article; onClose: () => void }) {
  return (
    <SafeAreaView style={[styles.safe, { flex: 1 }]} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={onClose}>
          <Feather name="arrow-left" size={16} color={Colors.text} />
          <Text style={styles.backText}>Learn & Improve</Text>
        </TouchableOpacity>
        <View style={[styles.detailHero, { backgroundColor: article.color + "20" }]}>
          <View style={[styles.detailIconWrap, { backgroundColor: article.color + "30" }]}>
            <Feather name={article.icon} size={36} color={article.color} />
          </View>
          <View style={[styles.detailCatPill, { backgroundColor: article.color + "22" }]}>
            <Text style={[styles.detailCat, { color: article.color }]}>{article.category}</Text>
          </View>
          <Text style={styles.detailTitle}>{article.title}</Text>
          <Text style={styles.detailMeta}>{article.readTime} read</Text>
        </View>
        <View style={styles.detailContent}>
          <Text style={styles.detailSummary}>{article.summary}</Text>
          {article.body.map((p, i) => <Text key={i} style={styles.detailPara}>{p}</Text>)}
          <View style={[styles.takeaways, { borderColor: article.color + "44", backgroundColor: article.color + "0e" }]}>
            <Text style={[styles.takeawaysTitle, { color: article.color }]}>Key Takeaways</Text>
            {article.takeaways.map((t, i) => (
              <View key={i} style={styles.takeawayRow}>
                <Feather name="check-circle" size={13} color={article.color} />
                <Text style={styles.takeawayText}>{t}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default function LearnScreen() {
  const [filter, setFilter]   = useState("All");
  const [selected, setSelected] = useState<Article | null>(null);

  const filtered  = filter === "All" ? ARTICLES : ARTICLES.filter((a) => a.category === filter);
  const [feature, ...rest] = filtered;

  if (selected) return <Detail article={selected} onClose={() => setSelected(null)} />;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.pageTitle}>Learn & Improve</Text>
          <Text style={styles.pageSub}>Bite-sized wellness insights for your daily life</Text>
        </View>

        {/* Quick tips */}
        <Text style={styles.sectionLabel}>Quick Tips</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.md, paddingBottom: 8 }}>
          {QUICK_TIPS.map((tip, i) => (
            <View key={i} style={styles.tipCard}>
              <Text style={styles.tipEmoji}>{tip.emoji}</Text>
              <Text style={styles.tipText}>{tip.text}</Text>
            </View>
          ))}
        </ScrollView>

        {/* Category filter */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.md, paddingBottom: 8 }}>
          {CATEGORIES.map((cat) => (
            <TouchableOpacity key={cat} style={[styles.chip, filter === cat && styles.chipActive]} onPress={() => setFilter(cat)}>
              <Text style={[styles.chipText, filter === cat && styles.chipTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={styles.sectionLabel}>Articles</Text>

        {/* Featured */}
        {feature && (
          <TouchableOpacity style={[styles.featured, { backgroundColor: feature.color + "18", borderColor: feature.color + "44" }]} onPress={() => setSelected(feature)} activeOpacity={0.88}>
            <View style={styles.featuredMeta}>
              <View style={[styles.catPill, { backgroundColor: feature.color + "22" }]}>
                <Text style={[styles.catText, { color: feature.color }]}>{feature.category}</Text>
              </View>
              <Feather name="clock" size={11} color={Colors.textMuted} />
              <Text style={styles.readTime}>{feature.readTime}</Text>
            </View>
            <View style={[styles.featuredIcon, { backgroundColor: feature.color + "30" }]}>
              <Feather name={feature.icon} size={32} color={feature.color} />
            </View>
            <Text style={styles.featuredTitle}>{feature.title}</Text>
            <Text style={styles.featuredSummary}>{feature.summary}</Text>
          </TouchableOpacity>
        )}

        {/* List */}
        <View style={{ paddingHorizontal: spacing.md }}>
          {rest.map((article) => (
            <TouchableOpacity key={article.id} style={styles.articleRow} onPress={() => setSelected(article)} activeOpacity={0.85}>
              <View style={[styles.articleIcon, { backgroundColor: article.color + "22" }]}>
                <Feather name={article.icon} size={20} color={article.color} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.articleMeta}>
                  <View style={[styles.catPill, { backgroundColor: article.color + "22" }]}>
                    <Text style={[styles.catText, { color: article.color }]}>{article.category}</Text>
                  </View>
                  <Text style={styles.readTime}>{article.readTime}</Text>
                </View>
                <Text style={styles.articleTitle}>{article.title}</Text>
                <Text style={styles.articleSummary}>{article.summary}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:            { flex: 1, backgroundColor: Colors.background },
  header:          { paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.sm },
  pageTitle:       { color: Colors.text, fontSize: fontSize.xxl, fontFamily: "Inter_700Bold" },
  pageSub:         { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular" },
  sectionLabel:    { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 1, paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: 6 },
  tipCard:         { width: 130, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, padding: spacing.sm, marginRight: 10, alignItems: "center", gap: 4 },
  tipEmoji:        { fontSize: 22 },
  tipText:         { color: Colors.text, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", textAlign: "center" },
  chip:            { paddingHorizontal: 14, paddingVertical: 6, borderRadius: radius.full, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card, marginRight: 8 },
  chipActive:      { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText:        { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_500Medium" },
  chipTextActive:  { color: "#0a1f14" },
  featured:        { marginHorizontal: spacing.md, borderRadius: radius.lg, borderWidth: 1, padding: spacing.md, marginBottom: spacing.md, alignItems: "center" },
  featuredMeta:    { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: spacing.sm },
  catPill:         { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  catText:         { fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold" },
  readTime:        { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  featuredIcon:    { width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center", marginBottom: spacing.sm },
  featuredTitle:   { color: Colors.text, fontSize: fontSize.lg, fontFamily: "Inter_700Bold", textAlign: "center", marginBottom: 4 },
  featuredSummary: { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 18 },
  articleRow:      { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.sm },
  articleIcon:     { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  articleMeta:     { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 3 },
  articleTitle:    { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  articleSummary:  { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", lineHeight: 16 },
  backBtn:         { flexDirection: "row", alignItems: "center", gap: 6, margin: spacing.md, padding: spacing.sm, backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, alignSelf: "flex-start" },
  backText:        { color: Colors.text, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  detailHero:      { alignItems: "center", padding: spacing.xl, gap: spacing.sm },
  detailIconWrap:  { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  detailCatPill:   { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  detailCat:       { fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold" },
  detailTitle:     { color: Colors.text, fontSize: fontSize.xl, fontFamily: "Inter_700Bold", textAlign: "center" },
  detailMeta:      { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  detailContent:   { padding: spacing.md },
  detailSummary:   { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", lineHeight: 22, marginBottom: spacing.md },
  detailPara:      { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", lineHeight: 20, marginBottom: spacing.md },
  takeaways:       { borderRadius: radius.md, borderWidth: 1, padding: spacing.md },
  takeawaysTitle:  { fontSize: fontSize.sm, fontFamily: "Inter_700Bold", marginBottom: spacing.sm },
  takeawayRow:     { flexDirection: "row", alignItems: "flex-start", gap: 6, marginBottom: 6 },
  takeawayText:    { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 16 },
});
