import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { spacing, radius, fontSize } from "../../constants/Theme";

type Tab = "Plans" | "Remedies";

const PLANS = [
  {
    id: "p1", title: "3-Day Stress Reset",       goal: "stress",    duration: "3 days",
    subtitle:  "Adaptogens, breathwork and nourishing foods to calm your nervous system.",
    steps:     ["Morning ashwagandha tea", "4-7-8 breathwork", "Anti-inflammatory lunch", "Evening magnesium protocol"],
    color:     "#F5A623",
  },
  {
    id: "p2", title: "7-Day Sleep Improvement",  goal: "sleep",     duration: "7 days",
    subtitle:  "A full-week protocol using sleep hygiene science and herbal support.",
    steps:     ["No caffeine after 2 PM", "Dim lights at 8 PM", "Chamomile + valerian tea", "Cool bedroom (18°C)"],
    color:     "#8B7FD4",
  },
  {
    id: "p3", title: "5-Day Energy Recharge",    goal: "energy",    duration: "5 days",
    subtitle:  "Morning sunlight, balanced nutrition and gentle movement to restore vitality.",
    steps:     ["Sunlight within 30 min of waking", "Delay caffeine 90 min", "Protein-first breakfast", "10-min post-lunch walk"],
    color:     "#4db87a",
  },
  {
    id: "p4", title: "Immunity Builder",          goal: "immunity",  duration: "14 days",
    subtitle:  "A two-week plan supporting your immune system through food and lifestyle.",
    steps:     ["30+ plants per week", "Daily vitamin D", "Elderberry tincture", "Cold-contrast shower"],
    color:     "#45B7AA",
  },
];

const REMEDIES = [
  {
    id: "r1", title: "Ginger Digestive Tea",    category: "Digestion", prepTime: "10 min",
    description: "Warming, traditional remedy for bloating, nausea and sluggish digestion.",
    ingredients: ["1 inch fresh ginger", "1 cup water", "1 tsp raw honey", "Squeeze of lemon"],
    steps: ["Slice ginger thinly", "Simmer in water 10 min", "Strain and cool slightly", "Add honey and lemon"],
  },
  {
    id: "r2", title: "Golden Sleep Milk",        category: "Sleep",     prepTime: "5 min",
    description: "A warming evening drink with turmeric and nutmeg to support restful sleep.",
    ingredients: ["1 cup oat milk", "½ tsp turmeric", "Pinch of nutmeg", "1 tsp honey"],
    steps: ["Warm milk gently (don't boil)", "Whisk in turmeric and nutmeg", "Sweeten with honey", "Drink 30 min before bed"],
  },
  {
    id: "r3", title: "Elderberry Immune Syrup", category: "Immunity",  prepTime: "30 min",
    description: "Traditional immune-supporting syrup with elderberries and warming spices.",
    ingredients: ["1 cup dried elderberries", "3 cups water", "1 tsp ginger", "1 cup raw honey"],
    steps: ["Simmer elderberries 30 min", "Mash and strain through cloth", "Cool to lukewarm", "Stir in honey. Refrigerate."],
  },
  {
    id: "r4", title: "Stress Relief Tonic",     category: "Stress",    prepTime: "5 min",
    description: "Adaptogenic blend of ashwagandha and lemon balm to support the nervous system.",
    ingredients: ["½ tsp ashwagandha powder", "1 cup warm milk", "Pinch of cinnamon", "1 tsp honey"],
    steps: ["Warm milk gently", "Whisk in ashwagandha", "Add cinnamon and honey", "Drink in the morning"],
  },
];

const GOAL_COLOR: Record<string, string> = {
  stress: "#F5A623", sleep: "#8B7FD4", energy: "#4db87a", immunity: "#45B7AA",
};

export default function PlansScreen() {
  const [tab, setTab]             = useState<Tab>("Plans");
  const [expanded, setExpanded]   = useState<string | null>(null);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Wellness Plans</Text>
        <View style={styles.tabs}>
          {(["Plans", "Remedies"] as Tab[]).map((t) => (
            <TouchableOpacity key={t} style={[styles.tabBtn, tab === t && styles.tabBtnActive]} onPress={() => setTab(t)}>
              <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {tab === "Plans" && PLANS.map((plan) => {
          const color = plan.color;
          const open  = expanded === plan.id;
          return (
            <TouchableOpacity key={plan.id} style={styles.card} onPress={() => setExpanded(open ? null : plan.id)} activeOpacity={0.88}>
              <View style={styles.cardTop}>
                <View style={[styles.goalPill, { backgroundColor: color + "22" }]}>
                  <Text style={[styles.goalText, { color }]}>{plan.goal}</Text>
                </View>
                <Text style={[styles.duration, { color: Colors.textMuted }]}>{plan.duration}</Text>
              </View>
              <Text style={styles.cardTitle}>{plan.title}</Text>
              <Text style={styles.cardSub}>{plan.subtitle}</Text>
              {open && (
                <View style={styles.stepsWrap}>
                  {plan.steps.map((s, i) => (
                    <View key={i} style={styles.step}>
                      <View style={[styles.stepDot, { backgroundColor: color }]} />
                      <Text style={styles.stepText}>{s}</Text>
                    </View>
                  ))}
                </View>
              )}
              <View style={styles.cardFooter}>
                <Feather name={open ? "chevron-up" : "chevron-down"} size={14} color={Colors.textDim} />
                <Text style={styles.tapHint}>{open ? "Less" : "See steps"}</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        {tab === "Remedies" && REMEDIES.map((rem) => {
          const open = expanded === rem.id;
          return (
            <TouchableOpacity key={rem.id} style={styles.card} onPress={() => setExpanded(open ? null : rem.id)} activeOpacity={0.88}>
              <View style={styles.cardTop}>
                <View style={[styles.goalPill, { backgroundColor: Colors.primary + "22" }]}>
                  <Text style={[styles.goalText, { color: Colors.primary }]}>{rem.category}</Text>
                </View>
                <Text style={[styles.duration, { color: Colors.textMuted }]}>⏱ {rem.prepTime}</Text>
              </View>
              <Text style={styles.cardTitle}>{rem.title}</Text>
              <Text style={styles.cardSub}>{rem.description}</Text>
              {open && (
                <>
                  <Text style={styles.subheading}>Ingredients</Text>
                  {rem.ingredients.map((ing, i) => (
                    <Text key={i} style={styles.ingredient}>• {ing}</Text>
                  ))}
                  <Text style={styles.subheading}>Instructions</Text>
                  {rem.steps.map((s, i) => (
                    <View key={i} style={styles.step}>
                      <Text style={[styles.stepNum, { color: Colors.primary }]}>{i + 1}.</Text>
                      <Text style={styles.stepText}>{s}</Text>
                    </View>
                  ))}
                </>
              )}
              <View style={styles.cardFooter}>
                <Feather name={open ? "chevron-up" : "chevron-down"} size={14} color={Colors.textDim} />
                <Text style={styles.tapHint}>{open ? "Less" : "Show details"}</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:          { flex: 1, backgroundColor: Colors.background },
  header:        { paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.sm },
  pageTitle:     { color: Colors.text, fontSize: fontSize.xxl, fontFamily: "Inter_700Bold", marginBottom: spacing.sm },
  tabs:          { flexDirection: "row", backgroundColor: Colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" },
  tabBtn:        { flex: 1, alignItems: "center", paddingVertical: spacing.sm },
  tabBtnActive:  { backgroundColor: Colors.primary + "22" },
  tabText:       { color: Colors.textMuted, fontSize: fontSize.sm, fontFamily: "Inter_500Medium" },
  tabTextActive: { color: Colors.primary },
  scroll:        { padding: spacing.md, paddingTop: 0 },
  card:          { backgroundColor: Colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: Colors.border, padding: spacing.md, marginBottom: spacing.md },
  cardTop:       { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.sm },
  goalPill:      { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  goalText:      { fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", textTransform: "capitalize" },
  duration:      { fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
  cardTitle:     { color: Colors.text, fontSize: fontSize.md, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
  cardSub:       { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", lineHeight: 18, marginBottom: spacing.sm },
  stepsWrap:     { marginTop: spacing.sm, gap: 6 },
  step:          { flexDirection: "row", alignItems: "flex-start", gap: 8, marginBottom: 4 },
  stepDot:       { width: 8, height: 8, borderRadius: 4, marginTop: 5, flexShrink: 0 },
  stepNum:       { fontSize: fontSize.sm, fontFamily: "Inter_700Bold", width: 16 },
  stepText:      { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 18 },
  subheading:    { color: Colors.textMuted, fontSize: fontSize.xs, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 1, marginTop: spacing.sm, marginBottom: 4 },
  ingredient:    { color: Colors.textDim, fontSize: fontSize.sm, fontFamily: "Inter_400Regular", marginBottom: 2 },
  cardFooter:    { flexDirection: "row", alignItems: "center", gap: 4, marginTop: spacing.sm },
  tapHint:       { color: Colors.textDim, fontSize: fontSize.xs, fontFamily: "Inter_400Regular" },
});
