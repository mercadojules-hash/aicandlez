export const Colors = {
  background:  "#0a1f14",
  card:        "#122b1c",
  cardAlt:     "#193825",
  border:      "#2a4a35",
  primary:     "#4db87a",
  primaryDark: "#39925f",
  primaryLight:"#72d49a",
  accent:      "#c8a84b",
  text:        "#f0ede6",
  textMuted:   "#8aad9a",
  textDim:     "#5a7a68",
  success:     "#4db87a",
  error:       "#e07070",
  white:       "#ffffff",
  overlay:     "rgba(10,31,20,0.88)",
};

export type ColorScheme = typeof Colors;
