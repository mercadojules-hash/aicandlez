import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

const port = Number(process.env.PORT ?? 5173);

export default defineConfig({
  plugins: [react(), tailwindcss({ optimize: false })],
  resolve: {
    alias: { "@": path.resolve(import.meta.dirname, "src") },
    dedupe: ["react", "react-dom"],
  },
  root:  path.resolve(import.meta.dirname),
  build: { outDir: "dist", emptyOutDir: true },
  server: {
    port, host: "0.0.0.0", allowedHosts: true,
    proxy: { "/api": { target: "http://localhost:8080", changeOrigin: true } },
  },
  preview: { port, host: "0.0.0.0", allowedHosts: true },
});
