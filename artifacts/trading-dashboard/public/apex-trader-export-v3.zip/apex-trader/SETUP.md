# Apex Trader — Local Setup

## Requirements
- Node.js 20+  npm 10+  PostgreSQL

## Start
```bash
npm install             # workspace install

# Terminal 1 — backend (Express on :8080)
npm run dev:backend

# Terminal 2 — frontend (Vite on :5173)
npm run dev:frontend
```

## Environment
Copy .env.example → backend/.env and frontend/.env
Minimum required: DATABASE_URL, SESSION_SECRET, CLERK_* keys, VITE_CLERK_PUBLISHABLE_KEY

## Charts
Command Center (/command) fetches 8 symbols via:
  GET /api/candles?symbol=BTCUSD&timeframe=15m&limit=60
Vite proxies /api/* → localhost:8080 automatically.

## Removed Replit-only dependencies
- stripe-replit-sync  →  standard stripe npm package + env vars
- Replit Vite plugins →  removed from vite.config.ts
- Replit connector proxy → reads STRIPE_SECRET_KEY directly from env
