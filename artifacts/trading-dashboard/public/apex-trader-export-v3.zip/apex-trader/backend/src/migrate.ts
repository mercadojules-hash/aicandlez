// Standalone migration runner.
// Drizzle ORM manages the schema — run: npx drizzle-kit push
// The Replit-only Stripe sync package is not used here.
const databaseUrl = process.env["DATABASE_URL"];
if (!databaseUrl) {
  console.warn("[migrate] DATABASE_URL not set — skipping");
  process.exit(0);
}
console.log("[migrate] Schema managed by Drizzle ORM. Run: npx drizzle-kit push");
process.exit(0);
