import Stripe from "stripe";

export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    const secretKey     = process.env.STRIPE_SECRET_KEY;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secretKey || !webhookSecret) {
      console.warn("[webhook] Stripe env vars missing — skipping");
      return;
    }
    const stripe = new Stripe(secretKey, { apiVersion: "2025-08-27.basil" as any });
    const event  = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    console.log(`[webhook] Stripe event: ${event.type}`);
  }
}
