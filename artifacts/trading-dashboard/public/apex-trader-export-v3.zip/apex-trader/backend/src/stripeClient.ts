import Stripe from "stripe";

// Standalone Stripe client — reads STRIPE_SECRET_KEY / STRIPE_PUBLISHABLE_KEY from env.

export async function getUncachableStripeClient(): Promise<Stripe> {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY env var required for billing");
  return new Stripe(key, { apiVersion: "2025-08-27.basil" as any });
}

export async function getStripePublishableKey(): Promise<string> {
  const key = process.env.STRIPE_PUBLISHABLE_KEY;
  if (!key) throw new Error("STRIPE_PUBLISHABLE_KEY env var required");
  return key;
}

export async function getStripeSync(): Promise<never> {
  throw new Error("getStripeSync not available in standalone mode");
}
