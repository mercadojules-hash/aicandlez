# Apex Trader — AI Crypto Trading Dashboard

**Version:** 1.0.0 · **Build date:** May 2026

Apex Trader is a full-stack hybrid AI crypto trading dashboard built with
Vite + React (frontend) and Express 5 + PostgreSQL (backend). It provides
real-time multi-timeframe signal analysis, automated trade execution, risk
management, backtesting, sentiment scoring, and a live command center — all
in one integrated system.

---

## Feature Overview (19 Modules)

| # | Module | Path | Description |
|---|--------|------|-------------|
| 01 | Dashboard | `/` | Live signal tiles, EMA/RSI gauge, P&L summary |
| 02 | Trading | `/trading` | Market/Limit order entry, order book preview |
| 03 | Portfolio | `/portfolio` | Holdings overview, allocation pie chart |
| 04 | Simulation | `/simulation` | Paper-trade sandbox with virtual balance |
| 05 | Backtest | `/backtest` | Historical strategy replay with win/loss stats |
| 06 | Risk Manager | `/risk` | Position sizing, stop-loss/TP controls, drawdown |
| 07 | Trade Journal | `/journal` | Auto-logged trade history with tags & notes |
| 08 | Sentiment | `/sentiment` | AI fear/greed score + market sentiment summary |
| 09 | Asset Scanner | `/scanner` | Ranked BTC/ETH/SOL opportunity scanner with mini charts |
| 10 | Alerts | Global | Real-time BUY/SELL toast alerts with sound toggle |
| 11 | Correlation | `/correlation` | Cross-asset correlation matrix |
| 12 | Exchange | `/exchange` | Kraken API integration module |
| 13 | AI Analysis | `/analysis` | GPT-powered trade reasoning summaries |
| 14 | Trailing Stops | Engine | Auto trailing-stop management on open positions |
| 15 | Settings | Drawer | Global config: allocation, confidence, risk params |
| 16 | Logs | `/logs` | Engine error log and system event viewer |
| 17 | Signal Debug | `/debug` | MTF signal funnel, quality filters, volume/1H badges |
| 18 | Multi-Chart | `/charts` | EMA9/21 + volume Recharts per asset, configurable layout |
| 19 | Command Center | `/command` | One-screen unified view: charts + AI brief + risk status |

---

## Tech Stack

**Frontend**
- Vite 5 + React 18 + TypeScript
- Wouter (routing), TanStack Query v5 (data fetching)
- Recharts (charts), Tailwind CSS + shadcn/ui (components)
- lucide-react (icons)

**Backend**
- Express 5 + TypeScript (ESBuild bundled)
- Pino (structured JSON logging)
- Drizzle ORM + PostgreSQL (schema, migrations)
- Kraken REST API (candles, account, orders)

**Monorepo**
- pnpm workspaces
- Packages: `@workspace/trading-dashboard`, `@workspace/api-server`, `@workspace/db`, `@workspace/api-spec`

---

## Requirements

- Node.js 20+
- pnpm 9+
- PostgreSQL 15+ (or use Replit's built-in PostgreSQL)
- (Optional) Kraken API key for live trading

---

## Quick Start

### 1. Clone / open in Replit

If using Replit, open the project and all dependencies are auto-installed.

### 2. Set environment variables

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

### 3. Install dependencies

```bash
pnpm install
```

### 4. Run database migrations

```bash
pnpm --filter @workspace/db run migrate
```

### 5. Start the development servers

**API server** (port defined by `PORT` env var, default 8080):
```bash
pnpm --filter @workspace/api-server run dev
```

**Frontend** (port defined by `PORT` env var, default 5173):
```bash
pnpm --filter @workspace/trading-dashboard run dev
```

Or on Replit — just click **Run** and both workflows start automatically.

---

## Environment Variables

See `.env.example` for the full list. Key variables:

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DATABASE_URL` | Yes | — | PostgreSQL connection string |
| `SESSION_SECRET` | Yes | — | Express session secret (min 32 chars) |
| `KRAKEN_API_KEY` | No | — | Kraken API key (for live trading) |
| `KRAKEN_API_SECRET` | No | — | Kraken API secret (for live trading) |
| `PORT` | No | 8080/5173 | Service port (set automatically in Replit) |

---

## Trading Engine

The trading engine runs as a background loop (`tradingLoop.ts`) that:

1. Fetches 5m and 15m candles from Kraken for BTC, ETH, SOL
2. Runs AI decision logic (EMA crossover + RSI + MACD scoring)
3. Applies multi-timeframe (MTF) confirmation: both timeframes must agree
4. Applies signal quality filters:
   - **Volume confirmation** — current volume must be ≥ 85% of 20-bar average
   - **Sideways filter** — blocks trades when EMA spread is < 0.15% (range-bound)
   - **1H trend alignment** (optional) — 1H EMA9 must align with signal direction
5. Checks correlation filter (avoids highly correlated pairs simultaneously)
6. Executes auto trades when `autoMode: true` and all gates pass

### Signal Quality Filters

Control filters via the Signal Debug page (`/debug`) or via API:

```bash
# Toggle volume filter
curl -X POST /api/engine/filters \
  -H "Content-Type: application/json" \
  -d '{"volumeFilter": true}'

# Toggle 1H trend alignment filter
curl -X POST /api/engine/filters \
  -H "Content-Type: application/json" \
  -d '{"require1HTrend": false}'
```

### Key API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/engine/status` | Full engine state, signal log, breakdowns |
| POST | `/api/engine/start` | Start trading loop |
| POST | `/api/engine/stop` | Stop trading loop |
| POST | `/api/engine/testmode` | Toggle test mode `{ enabled: boolean }` |
| POST | `/api/engine/filters` | Toggle quality filters |
| GET | `/api/candles` | Fetch OHLCV candles `?symbol=BTCUSD&timeframe=5m&limit=60` |
| GET/PUT | `/api/settings` | Read/write engine settings |
| GET | `/api/trades` | Trade history |
| POST | `/api/scanner/scan` | Run asset scanner |
| GET | `/api/backtest` | Run backtest `?symbol=BTCUSD&days=30` |
| GET | `/api/sentiment` | Market sentiment scores |

---

## Configuration (Settings)

Use the floating gear icon (⚙) on any page or `PUT /api/settings`:

```json
{
  "allocation":       1000,
  "maxTradesPerDay":  5,
  "minConfidence":    60,
  "autoMode":         false,
  "stopLossPercent":  2,
  "takeProfitPercent": 4,
  "killSwitch":       false
}
```

**minConfidence** defaults to **60%** — signals below this threshold are blocked.

---

## Test Mode

Toggle test mode in the Signal Debug page. In test mode:
- Confidence threshold drops to 35%
- Single-timeframe strong signals (≥ 60%) are allowed
- Quality filters (volume, sideways, 1H) are bypassed
- Trades are tagged `mode: "test"` in the database

---

## Architecture Diagram

```
Browser (Vite + React)
    │
    ├── /api/*  ──────────────────► Express API Server
    │                                    │
    │                                    ├── Kraken REST API (candles, account)
    │                                    ├── tradingLoop.ts (background engine)
    │                                    └── PostgreSQL (via Drizzle ORM)
    │
    └── /  ───────────────────────► Vite dev server (static SPA)
```

All traffic is routed through a shared reverse proxy (Replit artifact router).

---

## Database Schema

Key tables (all in `lib/db/src/schema.ts`):

- `signals` — MTF signal log (decision, confidence, timeframe)
- `trades` — executed trades (side, size, price, mode, P&L)
- `tradeJournal` — extended journal entries (reasoning, tags, notes)
- `settings` — engine configuration (single row, id="default")

---

## Support & Customisation

- Add new symbols: extend `SUPPORTED_SYMBOLS` in `tradingLoop.ts`
- Add new indicators: extend `runAIDecision()` in `tradingLoop.ts`
- Add new timeframes: modify `computeMTFDecision()` to fetch a third TF
- Add exchange support: create a new file alongside `lib/exchange.ts`

---

*Apex Trader is a research and educational tool. Live trading involves risk.
Always test thoroughly in simulation mode before enabling auto-trading.*
