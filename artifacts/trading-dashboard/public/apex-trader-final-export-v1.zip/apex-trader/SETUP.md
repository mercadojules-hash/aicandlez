# Apex Trader — Quick Setup Checklist

Use this checklist to get Apex Trader running in under 5 minutes.

## Checklist

- [ ] **Node.js 20+** and **pnpm 9+** installed
- [ ] **PostgreSQL** running (or use Replit's built-in DB)
- [ ] Copy `.env.example` → `.env` and fill in `DATABASE_URL` and `SESSION_SECRET`
- [ ] Run `pnpm install` in the project root
- [ ] Run `pnpm --filter @workspace/db run migrate` to create tables
- [ ] Start the API server: `pnpm --filter @workspace/api-server run dev`
- [ ] Start the frontend: `pnpm --filter @workspace/trading-dashboard run dev`
- [ ] Open `http://localhost:5173` (or your Replit preview URL)
- [ ] Go to **Signal Debug** (`/debug`) to verify the engine is ticking
- [ ] Go to **Settings** (gear icon) to set your allocation and confidence threshold
- [ ] Enable **Test Mode** in Signal Debug to see signals without real trades
- [ ] When ready, enable **Auto Mode** in Settings (with caution!)

## First-time Replit setup

1. Fork or import the project into your Replit account
2. Replit automatically provisions PostgreSQL — `DATABASE_URL` is pre-set
3. Go to **Secrets** and add `SESSION_SECRET` (any random 40+ char string)
4. Click **Run** — both workflows start automatically
5. Open the preview pane — the dashboard loads at the root path

## Kraken live trading (optional)

1. Create a Kraken account at https://www.kraken.com
2. Generate an API key with permissions: Query Funds, Query Orders, Create Orders
3. Add `KRAKEN_API_KEY` and `KRAKEN_API_SECRET` to your `.env` / Secrets
4. In Settings, set `autoMode: false` initially and test with simulation first
5. Enable `autoMode: true` only after confirming signals look good in test mode

## Safety recommendations

- Always start with `autoMode: false`
- Use test mode to validate signals before live trading
- Set a conservative `allocation` (e.g., $100) for initial live tests
- Enable `killSwitch: true` to immediately stop all auto-trading
- Monitor the Signal Debug page for block reasons and filter states

## Support

See `README.md` for full API reference and architecture details.
