import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout, MODULE_LIST } from "@/components/Layout";
import { AlertsProvider } from "@/components/AlertsProvider";
import { SettingsDrawer } from "@/components/SettingsDrawer";
import Dashboard from "@/pages/Dashboard";
import MarketData from "@/pages/MarketData";
import Indicators from "@/pages/Indicators";
import AIReasoning from "@/pages/AIReasoning";
import RiskManagement from "@/pages/RiskManagement";
import Simulation from "@/pages/Simulation";
import Backtest from "@/pages/Backtest";
import StrategyOptimizer from "@/pages/StrategyOptimizer";
import AssetScanner from "@/pages/AssetScanner";
import Portfolio from "@/pages/Portfolio";
import Correlation from "@/pages/Correlation";
import Journal from "@/pages/Journal";
import Validation from "@/pages/Validation";
import Sentiment from "@/pages/Sentiment";
import Exchange from "@/pages/Exchange";
import ComingSoon from "@/pages/ComingSoon";
import SystemVerification from "@/pages/SystemVerification";
import SignalDebug from "@/pages/SignalDebug";
import MultiChart from "@/pages/MultiChart";
import CommandCenter from "@/pages/CommandCenter";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: false },
  },
});

const PENDING_PATHS = MODULE_LIST.filter((m) => m.status === "pending").map((m) => m.path);

function Router() {
  return (
    <Switch>
      <Route path="/">
        <Layout><Dashboard /></Layout>
      </Route>
      <Route path="/market">
        <Layout><MarketData /></Layout>
      </Route>
      <Route path="/indicators">
        <Layout><Indicators /></Layout>
      </Route>
      <Route path="/ai">
        <Layout><AIReasoning /></Layout>
      </Route>
      <Route path="/risk">
        <Layout><RiskManagement /></Layout>
      </Route>
      <Route path="/simulation">
        <Layout><Simulation /></Layout>
      </Route>
      <Route path="/backtest">
        <Layout><Backtest /></Layout>
      </Route>
      <Route path="/optimizer">
        <Layout><StrategyOptimizer /></Layout>
      </Route>
      <Route path="/scanner">
        <Layout><AssetScanner /></Layout>
      </Route>
      <Route path="/portfolio">
        <Layout><Portfolio /></Layout>
      </Route>
      <Route path="/correlation">
        <Layout><Correlation /></Layout>
      </Route>
      <Route path="/journal">
        <Layout><Journal /></Layout>
      </Route>
      <Route path="/validation">
        <Layout><Validation /></Layout>
      </Route>
      <Route path="/sentiment">
        <Layout><Sentiment /></Layout>
      </Route>
      <Route path="/exchange">
        <Layout><Exchange /></Layout>
      </Route>
      <Route path="/syscheck">
        <Layout><SystemVerification /></Layout>
      </Route>
      <Route path="/debug">
        <Layout><SignalDebug /></Layout>
      </Route>
      <Route path="/charts">
        <Layout><MultiChart /></Layout>
      </Route>
      <Route path="/command">
        <Layout><CommandCenter /></Layout>
      </Route>
      {PENDING_PATHS.map((path) => (
        <Route key={path} path={path}>
          <Layout><ComingSoon path={path} /></Layout>
        </Route>
      ))}
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AlertsProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <SettingsDrawer />
          <Toaster />
        </AlertsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
