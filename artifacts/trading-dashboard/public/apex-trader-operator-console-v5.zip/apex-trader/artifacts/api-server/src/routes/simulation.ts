import { Router } from "express";
import { requireAuth } from "../middlewares/requireAuth.js";
import {
  getUserAccountSummary,
  getUserTradeHistory,
  placeUserOrder,
  closeUserPosition,
  resetUserSimulation,
} from "../lib/userSimRegistry.js";
import { addJournalEntry } from "../lib/tradeJournalEngine.js";
import type { Request } from "express";

type AuthReq = Request & { clerkUserId: string };

const router = Router();

// GET /account — canonical account endpoint used by Command Center + portfolio panels
router.get("/account", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthReq).clerkUserId;
  try {
    const data = await getUserAccountSummary(userId);
    res.json(data);
  } catch (err) {
    req.log.error({ err, userId }, "GET /account failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// GET /simulation/account
router.get("/simulation/account", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthReq).clerkUserId;
  try {
    const data = await getUserAccountSummary(userId);
    res.json(data);
  } catch (err) {
    req.log.error({ err, userId }, "GET /simulation/account failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// GET /simulation/trades — closed trade history
router.get("/simulation/trades", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthReq).clerkUserId;
  try {
    const trades = await getUserTradeHistory(userId);
    res.json({ trades });
  } catch (err) {
    req.log.error({ err, userId }, "GET /simulation/trades failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// POST /simulation/order — place a simulated order
router.post("/simulation/order", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthReq).clerkUserId;
  const { symbol, side, sizeUSD } = req.body ?? {};

  if (!symbol || !side || typeof sizeUSD !== "number") {
    res.status(400).json({ error: "Required: symbol (string), side ('BUY'|'SELL'), sizeUSD (number)" });
    return;
  }
  if (side !== "BUY" && side !== "SELL") {
    res.status(400).json({ error: "side must be 'BUY' or 'SELL'" });
    return;
  }

  try {
    const result = await placeUserOrder(userId, { symbol, side, sizeUSD });
    res.status(result.success ? 201 : 400).json(result);
  } catch (err) {
    req.log.error({ err, userId }, "POST /simulation/order failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// POST /simulation/close/:positionId — close a position and auto-log to journal
router.post("/simulation/close/:positionId", requireAuth, async (req, res): Promise<void> => {
  const userId     = (req as AuthReq).clerkUserId;
  const positionId = String(req.params.positionId);
  const closeReason = (req.body?.closeReason as string | undefined) ?? "MANUAL";

  try {
    const result = await closeUserPosition(userId, positionId, closeReason);
    if (result.success && result.trade) {
      const t = result.trade;
      addJournalEntry({
        symbol:         t.symbol,
        displayName:    t.symbol.replace("USD", ""),
        side:           t.side,
        entryPrice:     t.entryPrice,
        exitPrice:      t.exitPrice,
        entryTime:      t.entryTime,
        exitTime:       t.exitTime,
        sizeUSD:        t.sizeUSD,
        realizedPnL:    t.realizedPnL,
        realizedPnLPct: t.realizedPnLPct,
        durationMs:     t.durationMs,
        closeReason:    closeReason as "MANUAL" | "TRAILING_STOP" | "RISK_KILL" | "AUTO",
        reasoning:      req.body?.reasoning,
        notes:          req.body?.notes,
        tags:           req.body?.tags,
      }).catch(() => { /* non-fatal */ });
    }
    res.status(result.success ? 200 : 404).json(result);
  } catch (err) {
    req.log.error({ err, userId }, "POST /simulation/close failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// POST /simulation/reset — wipe all positions and reset balance for this user
router.post("/simulation/reset", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthReq).clerkUserId;
  try {
    await resetUserSimulation(userId);
    res.json({ ok: true, message: "Simulation reset to $100,000 starting balance" });
  } catch (err) {
    req.log.error({ err, userId }, "POST /simulation/reset failed");
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

export default router;
