import { Link, useLocation } from "wouter";

// Brand-green token system — matches Signals/Crypto/Equities pages so the
// bottom nav feels like one continuous surface across the app.
const C   = "#66FF66";
const DIM = "#3a4a4a";
const BG  = "#000000";

const HomeIcon = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 22 22" fill="none" shapeRendering="geometricPrecision">
    <path d="M2 9.5L11 2L20 9.5V20H14V14H8V20H2V9.5Z"
      stroke={active ? C : DIM} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
      fill={active ? `${C}10` : "none"}/>
  </svg>
);

const SignalsIcon = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 22 22" fill="none" shapeRendering="geometricPrecision">
    {/* Sparkle / AI burst */}
    <path d="M11 2 L12.6 8.6 L19 10.2 L12.6 11.8 L11 18.4 L9.4 11.8 L3 10.2 L9.4 8.6 Z"
      stroke={active ? C : DIM} strokeWidth="1.3" strokeLinejoin="round"
      fill={active ? `${C}1A` : "none"}/>
    {active && <circle cx="11" cy="10.5" r="1.2" fill={C}/>}
  </svg>
);

const CryptoIcon = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 22 22" fill="none" shapeRendering="geometricPrecision">
    <circle cx="11" cy="11" r="8" stroke={active ? C : DIM} strokeWidth="1.5" fill={active ? `${C}08` : "none"}/>
    <path d="M11 7v1M11 14.5v1M8.5 10a2.5 2.5 0 0 1 2.5-2.5h1.5a2 2 0 1 1 0 4H10a2 2 0 1 1 0 4h2a2.5 2.5 0 0 1 2.5-2.5"
      stroke={active ? C : DIM} strokeWidth="1.3" strokeLinecap="round"/>
  </svg>
);

const EquitiesIcon = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 22 22" fill="none" shapeRendering="geometricPrecision">
    <line x1="6"  y1="3"  x2="6"  y2="6"  stroke={active ? C : DIM} strokeWidth="1.4" strokeLinecap="round"/>
    <rect x="4"  y="6"  width="4" height="9" rx="0.8"
      stroke={active ? C : DIM} strokeWidth="1.4" fill={active ? `${C}12` : "none"}/>
    <line x1="6"  y1="15" x2="6"  y2="19" stroke={active ? C : DIM} strokeWidth="1.4" strokeLinecap="round"/>
    <line x1="16" y1="4"  x2="16" y2="7"  stroke={active ? C : DIM} strokeWidth="1.4" strokeLinecap="round"/>
    <rect x="14" y="7"  width="4" height="7" rx="0.8"
      stroke={active ? C : DIM} strokeWidth="1.4" fill={active ? `${C}12` : "none"}/>
    <line x1="16" y1="14" x2="16" y2="19" stroke={active ? C : DIM} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);

const ProfileIcon = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 22 22" fill="none" shapeRendering="geometricPrecision">
    <circle cx="11" cy="7.5" r="3.5" stroke={active ? C : DIM} strokeWidth="1.5"
      fill={active ? `${C}10` : "none"}/>
    <path d="M3 19.5c0-3.866 3.582-7 8-7s8 3.134 8 7"
      stroke={active ? C : DIM} strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

const TABS = [
  { path:"/",         label:"Home",     Icon:HomeIcon     },
  { path:"/crypto",   label:"Crypto",   Icon:CryptoIcon   },
  { path:"/trade",    label:"Signals",  Icon:SignalsIcon  },
  { path:"/equities", label:"Equities", Icon:EquitiesIcon },
  { path:"/profile",  label:"Profile",  Icon:ProfileIcon  },
];

export function BottomNav() {
  const [location] = useLocation();
  const isActive = (p: string) => {
    if (p === "/")      return location === "/";
    // Signals tab (path /trade) should also light up when on /signals,
    // since both routes render the same AI Signals page.
    if (p === "/trade") return location === "/trade" || location.startsWith("/trade/")
                              || location === "/signals" || location.startsWith("/signals/");
    // Treat legacy /markets as Crypto for the indicator
    if (p === "/crypto") return location === "/crypto" || location.startsWith("/crypto/")
                              || location === "/markets" || location.startsWith("/markets/");
    return location === p || location.startsWith(p + "/");
  };

  return (
    <nav style={{
      background: "transparent",
      padding: "6px 14px calc(6px + env(safe-area-inset-bottom, 0px))",
      flexShrink: 0,
    }}>
      <div style={{
        background: "linear-gradient(180deg, rgba(4,10,6,0.96) 0%, rgba(0,0,0,0.98) 100%)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
        border: "1px solid rgba(102,255,102,0.14)",
        borderRadius: 28,
        display: "flex",
        boxShadow: [
          "0 8px 32px rgba(0,0,0,0.80)",
          "0 2px 10px rgba(0,0,0,0.60)",
          "0 0 28px rgba(102,255,102,0.06)",
          "0 0 0 0.5px rgba(102,255,102,0.12) inset",
        ].join(", "),
        overflow: "hidden",
      }}>

        <style>{`
          @keyframes nav-pop { 0%{transform:scale(1)} 40%{transform:scale(0.88)} 100%{transform:scale(1)} }
          .nav-tab:active > .nav-icon { animation: nav-pop 0.22s ease-out; }
        `}</style>

        {TABS.map(({ path, label, Icon }) => {
          const active = isActive(path);
          return (
            <Link key={path} href={path}
              className="nav-tab"
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 4,
                height: 58,
                textDecoration: "none",
                position: "relative",
                transition: "background 0.2s ease",
                background: active ? "rgba(102,255,102,0.06)" : "transparent",
              }}>

              {/* Active top indicator line */}
              {active && (
                <div style={{
                  position: "absolute",
                  top: 0,
                  left: "50%",
                  transform: "translateX(-50%)",
                  width: 28,
                  height: 2,
                  background: `linear-gradient(90deg, transparent, ${C}, transparent)`,
                  boxShadow: `0 0 10px ${C}80`,
                  borderRadius: "0 0 3px 3px",
                }}/>
              )}

              {/* Active ambient glow */}
              {active && (
                <div aria-hidden style={{
                  position: "absolute",
                  bottom: 6,
                  left: "50%",
                  transform: "translateX(-50%)",
                  width: 40,
                  height: 20,
                  borderRadius: "50%",
                  background: `radial-gradient(ellipse, ${C}18, transparent 70%)`,
                  pointerEvents: "none",
                }}/>
              )}

              <div className="nav-icon">
                <Icon active={active}/>
              </div>

              <span style={{
                fontSize: 8,
                fontFamily: "Inter, -apple-system, sans-serif",
                fontWeight: 700,
                letterSpacing: "0.09em",
                textTransform: "uppercase" as const,
                color: active ? C : DIM,
                transition: "color 0.2s ease",
              }}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
