# Apex Trader — Setup Guide

## Prerequisites
- Node.js 20+
- PostgreSQL (local or cloud)
- npm 10+

## Quick Start

```bash
# 1. Install all dependencies
npm install

# 2. Copy env file and fill in your values
cp .env.example .env
# Edit .env with your Clerk keys, DATABASE_URL, SESSION_SECRET

# 3. Run database migrations (from backend/)
cd backend && npx drizzle-kit push --config src/migrate.ts

# 4. Start the API server (terminal 1)
npm run dev:backend

# 5. Start the frontend dev server (terminal 2)
npm run dev:frontend
```

Frontend runs at: http://localhost:5173
API server runs at: http://localhost:8080

## Chart Rendering
The Command Center (/command) renders 8 mini charts (BTC/ETH/SOL/XRP/DOGE/AVAX/LINK/ADA).
Charts use a direct useEffect fetch from /api/candles (no React Query).
The vite.config.ts proxies /api/* → http://localhost:8080/api/* automatically.

## Import Tree (Chart Components)
CommandCenter → CryptoChartGrid → MiniChart (×8)
MiniChart fetches: /api/candles?symbol=BTCUSD&timeframe=15m&limit=60

## Architecture
- frontend/ — React 19 + Vite 7 + Tailwind 4 + Recharts
- backend/ — Express 5 + Drizzle ORM + PostgreSQL + Clerk auth
- lib/db/ — Drizzle schema + migrations
- lib/api-zod/ — Zod validation schemas (auto-generated)
- lib/api-client-react/ — React Query hooks (auto-generated)
