# Apex Trader v7 — Local Setup Guide
Stable baseline before: Robinhood integration · live exchange · WebSocket telemetry · real balances

---

## Prerequisites

| Tool    | Version  | Install                              |
|---------|----------|--------------------------------------|
| Node.js | >= 20    | https://nodejs.org or `nvm install 20` |
| pnpm    | >= 9     | `npm install -g pnpm@latest`         |
| PostgreSQL | any   | https://www.postgresql.org/download/ |

---

## 1. Install all dependencies

```bash
pnpm install
```

This resolves all `workspace:*` references across:
- `artifacts/trading-dashboard` (Vite + React frontend)
- `artifacts/api-server` (Express 5 API)
- `lib/api-zod` (Zod schemas — shared)
- `lib/db` (Drizzle ORM + PostgreSQL — shared)
- `lib/api-client-react` (React Query hooks — shared)

---

## 2. Environment variables

Create a `.env` file in `artifacts/api-server/`:

```env
# Required
DATABASE_URL=postgresql://user:password@localhost:5432/apex_trader
SESSION_SECRET=any-random-string-at-least-32-chars

# Optional — unlock Kraken LIVE mode (leave unset for simulation)
KRAKEN_API_KEY=
KRAKEN_API_SECRET=
EXCHANGE_LIVE_ENABLED=false
```

---

## 3. Push the database schema

```bash
pnpm --filter @workspace/db run push
```

---

## 4. Start both services

**Terminal 1 — API server** (runs on port 3001 by default):

```bash
PORT=3001 pnpm --filter @workspace/api-server run dev
```

**Terminal 2 — Frontend** (runs on port 5173 by default):

```bash
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/trading-dashboard run dev
```

Then open: http://localhost:5173

---

## 5. Alternatively — start both together

```bash
pnpm run dev:all
```

---

## Key URLs (local)

| Page             | URL                                |
|------------------|------------------------------------|
| Command Center   | http://localhost:5173/command      |
| Charts           | http://localhost:5173/charts       |
| Signal Debug     | http://localhost:5173/debug        |
| System Check     | http://localhost:5173/syscheck     |
| API Health       | http://localhost:3001/api/healthz  |
| Engine Status    | http://localhost:3001/api/engine/status |

---

## Exchange simulation (no API keys needed)

The system defaults to **SIMULATION mode** on Kraken.
12 exchanges available: Kraken · Binance · Coinbase · OKX · Bybit · Bitfinex · Gate.io · KuCoin · Huobi · MEXC · Phemex · **Uphold**

Switch exchange from the Broker/Exchange card on the Command Center.

---

## Workspace structure

```
apex-trader-v7/
├── artifacts/
│   ├── trading-dashboard/   ← Vite + React + Wouter + TanStack Query
│   └── api-server/          ← Express 5 + Drizzle ORM + pino logging
├── lib/
│   ├── api-zod/             ← Shared Zod schemas (OpenAPI-generated)
│   ├── api-client-react/    ← Shared React Query hooks (OpenAPI-generated)
│   ├── db/                  ← Drizzle schema + PostgreSQL client
│   └── api-spec/            ← OpenAPI spec (source for codegen)
├── package.json             ← Root monorepo config + dev:all script
├── pnpm-workspace.yaml      ← Workspace + catalog (macOS-compatible)
├── tsconfig.base.json       ← Shared strict TypeScript config
└── SETUP.md                 ← This file
```

---

## Notes

- The `pnpm-workspace.yaml` in this package has been patched to remove Linux-only
  binary overrides so that macOS (Apple Silicon + Intel) packages install correctly.
- If you encounter esbuild native binary issues: `pnpm rebuild esbuild`
- If you encounter vite issues: `pnpm --filter @workspace/trading-dashboard exec vite --clearScreen false`
